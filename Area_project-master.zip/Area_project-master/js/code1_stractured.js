function calculate() {
    var l = document.getElementById("length").value;
    var w = document.getElementById("Width").value;
    var res = Number(l) * Number(w);

     document.getElementById("ans").innerHTML = "The area =" + res;
    
//window.alert("The area =" + res)

 }
// var l = document.getElementById("length").value;
//     var w = document.getElementById("Width").value;
//     var res = Number(l) * Number(w);

//     // document.getElementById("ans").innerHTML = res;
    
// window.alert("The area =" + res)
